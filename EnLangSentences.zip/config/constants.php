<?php
define('ALL_LEGAL_CHAR', "/^[a-zA-Z0-9\s\p{Arabic}\p{P}]+$/u");
define('ALL_LEGAL_LATHIN_CHAR', "/^[a-zA-Z0-9\s\p{P}]+$/u");
define('STATIC_SENTENCE_NOT_FOUND', "No +sentences+ found");
define('SPEAK_SCORE', 4);
define('WRITE_SCORE', 3);
define('SUCCESS_SCORE', 3);
define('KNOW_SCORE', 1);
define('ADD_SCORE', 10);
define('ADD_DESCRIPTION_SCORE', 5);
