    <div wire:init="handleTyping" title="{{$oneSentence->description}}" id="typing_box" class="w-100 w-md-50 bg_dark text-white p-3 rounded shadow mt-3 transition_300">
    </div>
