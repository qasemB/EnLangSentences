<footer class="bg-light text-center d-flex justify-content-center align-items-center">
    © ENLangWords 2023
</footer>
