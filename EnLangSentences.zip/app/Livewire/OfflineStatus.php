<?php

namespace App\Livewire;

use Livewire\Component;

class OfflineStatus extends Component
{
    public function render()
    {
        return view('livewire.offline-status');
    }
}
