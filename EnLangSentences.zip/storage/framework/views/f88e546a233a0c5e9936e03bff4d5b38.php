    <div class="position-relative d-flex flex-column align-items-center justify-content-center <?php echo e($focused ? "is_blur" : ""); ?>">
        <div wire:ignore wire:init="handleTyping" title="<?php echo e($oneSentence->description); ?>" id="typing_box" class="w-100 w-md-50 bg_dark text-white p-3 rounded shadow mt-3 transition_300 <?php echo e($oneSentence->description != null ? "has_tag" : ""); ?>" wire:click="handleShowDescription">
        </div>
        <!--[if BLOCK]><![endif]--><?php if($showDescription): ?>
            <small class="d-block text-center mt-2 text_blue"><?php echo e($oneSentence->description); ?></small>
        <?php endif; ?> <!--[if ENDBLOCK]><![endif]-->
    </div>
<?php /**PATH D:\00programming\projects\EnLangSentences\resources\views/livewire/typing-sentence-box.blade.php ENDPATH**/ ?>