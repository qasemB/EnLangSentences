<?php $__env->startSection('content'); ?>
    <div class="w-100 h-100 d-flex justify-content-center align-items-center row m-0 p-0">
        <?php if($errors->any()): ?>
            <div class="col-12 col-md-6 alert alert-danger mt-2" id="error_alert">
                <ul class="m-0">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>
        <form class="col-12 col-md-6 col-lg-4 mt-5" method="POST" action="<?php echo e(route('login')); ?>">
            <?php echo csrf_field(); ?>
            <h1 class="text-center">Login</h1>
            <div class="form-floating my-3" data-bs-toggle="tooltip" data-bs-placement="top"
                data-bs-custom-class="custom-tooltip" data-bs-title="EX: 09121112233">
                <input name="phone" type="number" class="form-control" id="register_phone" placeholder="Just number"
                    value="<?php echo e(old('phone')); ?>">
                <label for="register_phone">Phone number</label>
            </div>

            <div class="form-floating my-3" data-bs-toggle="tooltip" data-bs-placement="top"
                data-bs-custom-class="custom-tooltip" data-bs-title="Letters and numbers + (@#$%)">
                <input name="password" type="password" class="form-control" id="register_pass" placeholder="Just number"
                    value="<?php echo e(old('password')); ?>">
                <label for="register_pass">Password</label>
            </div>
            <div class="form-check form-switch mt-4 d-flex justify-content-start align-items-center">
                <input name="rememberme" class="form-check-input me-2" type="checkbox" role="switch">
                <small class="form-check-small" >Remember me</label>
            </div>

            <div class="text-center mt-4">
                <button type="submit" class="btn btn_blue hoverable">Login</button>
            </div>

            <a href="/register" class="mt-5 d-block">I have not registered yet</a>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts._main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\00programming\projects\EnLangSentences\resources\views/auth/login.blade.php ENDPATH**/ ?>