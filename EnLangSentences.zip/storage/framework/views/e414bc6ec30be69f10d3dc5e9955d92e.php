<div>
    <div class="text-center mb-4">
        <!--[if BLOCK]><![endif]--><?php if(Auth::check()): ?>
            <button class="btn btn-light text_blue shadow" data-bs-toggle="offcanvas"
                data-bs-target="#addSentenceOffCanvas" aria-controls="addSentenceOffCanvas">Add your own sentence</button>
        <?php else: ?>
            <a href="<?php echo e(route('login')); ?>" class="btn btn-light text_blue shadow">Add your own sentence</a>
        <?php endif; ?> <!--[if ENDBLOCK]><![endif]-->
    </div>

    <div class="min_w_100 offcanvas offcanvas-start " data-bs-backdrop="static" tabindex="-1" id="addSentenceOffCanvas"
        aria-labelledby="addSentenceOffCanvasLabel" wire:ignore.self>
        <div class="offcanvas-header">
            <h5 class="offcanvas-title" id="addSentenceOffCanvasLabel">Add your own sentence</h5>
            <button type="button" class="btn-close" data-bs-dismiss="offcanvas" aria-label="Close"></button>
        </div>
        <div class="offcanvas-body">
            <div>
                <form wire:submit.prevent="handleSubmitForm">
                    <div class="form-floating" data-bs-toggle="tooltip" data-bs-placement="top"
                        data-bs-custom-class="custom-tooltip" data-bs-title="Write your own sentence">
                        <textarea class="form-control <?php $__errorArgs = ['sentence'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Write your own sentence"
                            id="add_sentence_sentence" style="height: 70px" wire:model.blur="sentence"></textarea>
                        <label for="add_sentence_sentence">Sentence</label>
                        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['sentence'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <small class="text-secondary"><?php echo e($message); ?></small>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> <!--[if ENDBLOCK]><![endif]-->
                    </div>

                    <div class="form-floating my-3" data-bs-toggle="tooltip" data-bs-placement="top"
                        data-bs-custom-class="custom-tooltip" data-bs-title="EX: Word1,word2,...">
                        <input type="text" class="form-control <?php $__errorArgs = ['target_words'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            id="add_sentence_target_words" placeholder="EX: Word1,word2,..."
                            wire:model.blur="target_words">
                        <label for="add_sentence_target_words">Target words</label>
                        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['target_words'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <small class="text-secondary"><?php echo e($message); ?></small>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> <!--[if ENDBLOCK]><![endif]-->
                    </div>

                    <div class="form-floating" data-bs-toggle="tooltip" data-bs-placement="top"
                        data-bs-custom-class="custom-tooltip" data-bs-title="What does focus on?">
                        <select class="form-select <?php $__errorArgs = ['category_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            id="add_sentence_category" wire:model.change="category_id">
                            <option selected>Select a category</option>
                            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($category->id); ?>"><?php echo e($category->title); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <!--[if ENDBLOCK]><![endif]-->
                        </select>
                        <label for="add_sentence_category">Category</label>
                        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['category_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <small class="text-secondary"><?php echo e($message); ?></small>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> <!--[if ENDBLOCK]><![endif]-->
                    </div>

                    <div class="my-3 rounded border px-3 py-1" data-bs-toggle="tooltip" data-bs-placement="top"
                        data-bs-custom-class="custom-tooltip" data-bs-title="what level is it?">
                        <label for="sentence_lavel" class="form-label">Level <?php echo e($level); ?></label>
                        <input type="range" class="form-range" min="1" max="6" id="sentence_lavel"
                            wire:model.blur="level">
                        <div class="d-flex justify-content-between">
                            <small class="text-secondary">Beginner</small>
                            <small class="text-secondary">Professional</small>
                        </div>
                        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['level'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <small class="text-danger"><?php echo e($message); ?></small>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> <!--[if ENDBLOCK]><![endif]-->
                    </div>

                    <div class="form-floating" data-bs-toggle="tooltip" data-bs-placement="top"
                        data-bs-custom-class="custom-tooltip" data-bs-title="Describe if needed (EX: Grammar note)">
                        <textarea class="form-control <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            placeholder="Describe if needed (EX: Grammar note)" id="add_sentence_description" style="height: 60px"
                            wire:model.blur="description"></textarea>
                        <label for="add_sentence_description">Description</label>
                        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <small class="text-secondary"><?php echo e($message); ?></small>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> <!--[if ENDBLOCK]><![endif]-->
                    </div>

                    <div class="form-check form-switch mt-4 d-flex justify-content-start align-items-center"
                        data-bs-toggle="tooltip" data-bs-placement="top" data-bs-custom-class="custom-tooltip"
                        data-bs-title="Just show it to me">
                        <input class="form-check-input me-2 <?php $__errorArgs = ['hide_for_others'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            type="checkbox" role="switch" id="add_sentence_for_me" wire:model.blur="hide_for_others">
                        <label class="form-check-label" for="add_sentence_for_me">Just for me</label>
                        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['hide_for_others'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <small class="text-secondary ms-2"><?php echo e($message); ?></small>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> <!--[if ENDBLOCK]><![endif]-->
                    </div>

                    <div class="text-center mt-3">
                        <button type="submit" class="btn btn_blue hoverable">submit</button>
                    </div>

                </form>
            </div>
        </div>
    </div>
</div>

<?php /**PATH D:\00programming\projects\EnLangSentences\resources\views/livewire/add-sentence.blade.php ENDPATH**/ ?>