<div class="text-center">
    <li class="nav-item">
        <span class="nav-link text-center" aria-current="page">امتیاز همکاری:
            <?php echo e($colabrateScore); ?></span>
    </li>
    <li class="nav-item">
        <span class="nav-link text-center" aria-current="page">امتیاز تمرین:
            <?php echo e($practiceScore); ?></span>
    </li>
    <li class="nav-item">
        <span class="nav-link text-center" aria-current="page">تعداد روزهای تمرین:
            <?php echo e($practiceDays); ?></span>
    </li>

    <i class="fas fa-refresh text_blue pointer hoverable_text" wire:click="calculateScores"></i>
</div>
<?php /**PATH D:\00programming\projects\EnLangSentences\resources\views/livewire/menu-scores.blade.php ENDPATH**/ ?>