<footer class="bg-light text-center d-flex justify-content-center align-items-center">
    © ENLangWords 2023
</footer>
<?php /**PATH D:\00programming\projects\EnLangSentences\resources\views/partials/mainFooter.blade.php ENDPATH**/ ?>