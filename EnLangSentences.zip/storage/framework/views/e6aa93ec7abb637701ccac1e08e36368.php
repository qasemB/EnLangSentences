<?php $__env->startSection('content'); ?>
    <div class="w-100 h-100 d-flex justify-content-center align-items-center row flex-column m-0 p-0">
        <?php if($errors->any()): ?>
            <div class="col-12 col-md-6 alert alert-danger mt-2" id="error_alert">
                <ul class="m-0">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>
        <form
        class="col-12 col-md-6 col-lg-4 mt-5"
        method="POST"
        action="<?php echo e(route('register', ['id' => 1])); ?>"
        >
            <?php echo csrf_field(); ?>
            <h1 class="text-center">Join us</h1>
            <div class="form-floating my-3" data-bs-toggle="tooltip" data-bs-placement="top"
                data-bs-custom-class="custom-tooltip" data-bs-title="EX: 09121112233 (11 Digits)">
                <input name="phone" type="number" class="form-control" id="register_phone" placeholder="Just number" value="<?php echo e(old('phone')); ?>">
                <label for="register_phone">Phone number</label>
            </div>
            <div class="form-floating my-3" data-bs-toggle="tooltip" data-bs-placement="top"
                data-bs-custom-class="custom-tooltip" data-bs-title="Letters + Numbers + (@#$%) At least 8">
                <input name="password" type="password" class="form-control" id="register_pass" placeholder="Just number">
                <label for="register_pass">Password</label>
            </div>
            <div class="form-floating my-3" data-bs-toggle="tooltip" data-bs-placement="top"
                data-bs-custom-class="custom-tooltip" data-bs-title="Repeat the above">
                <input name="password_confirmation" type="password" class="form-control" id="register_con_pass"
                    placeholder="Just number">
                <label for="register_con_pass">Confirm password</label>
            </div>

            <div class="text-center mt-4">
                <button type="submit" class="btn btn_blue hoverable">Register</button>
            </div>

            <a href="/login" class="d-block mt-5">I have already registered</a>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts._main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\00programming\projects\EnLangSentences\resources\views/auth/register.blade.php ENDPATH**/ ?>