<div wire:offline id="offline_elem" title="ارتباط شما با اینترنت قطع است">
    <i class="fa-solid fa-wifi text-danger" ></i>
    <span class="text-danger">!</span>
</div>
<?php /**PATH D:\00programming\projects\EnLangSentences\resources\views/livewire/offline-status.blade.php ENDPATH**/ ?>