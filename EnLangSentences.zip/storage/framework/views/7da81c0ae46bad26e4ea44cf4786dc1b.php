<div class="row col-12 justify-content-center align-items-center px-0">
    <div class="w-100 w-md-50 p-3 rounded shadow mt-4">
        
        <label style="direction: rtl" class="d-block">
            الان نوبت توئه، جمله رو
            <!--[if BLOCK]><![endif]--><?php if($isEven): ?>
                <span class="text_pink">بگو</span>
            <?php else: ?>
                <span class="text_pink">تایپ کن</span>
            <?php endif; ?> <!--[if ENDBLOCK]><![endif]-->
            
        </label>
        <textarea wire:ignore wire:focusin="handleFocus(1)" wire:focusout="handleFocus(0)" onpaste="return false;" id="typing_input"
            class="form-control" style="height: 60px"></textarea>

        <div id="speech_record_btn_box" class="position-relative mt-3">
            <button id="speech_record_btn" class="btn btn-primary rounded-circle btn-lg pointer <?php echo e($isEven ? "" : "d-none"); ?>">
                <i class="fas fa-microphone text-white" style="position: relative; top: 4px"></i>
            </button>
            <!--[if BLOCK]><![endif]--><?php if(Auth::check()): ?>
                <span style="position: absolute; right: 5px">کل امتیاز: <?php echo e(Auth::user()->practicing_score); ?></span>
            <?php endif; ?> <!--[if ENDBLOCK]><![endif]-->
        </div>
    </div>

    <div class="text-end mt-3 w-100 w-md-50 d-flex justify-content-between mb-4">
        <!--[if BLOCK]><![endif]--><?php if(Auth::check()): ?>
            <span class="text_pink pointer" wire:click="submitAndGoNext(false)">
                یاد نگرفتم! بعدی
            </span>

            <span class="<?php echo e($currentScore > 5 ? 'text-success' : ''); ?>"><?php echo e($currentScore); ?></span>

            <span class="text_blue pointer" wire:click="submitAndGoNext(true)">
                یاد گرفتم! بعدی
            </span>
        <?php else: ?>
            <a href="/login" class="text_pink pointer" wire:click="submitAndGoNext(false)">
                یاد نگرفتم! بعدی
            </a>

            <a href="/login" class="text_blue pointer" wire:click="submitAndGoNext(true)">
                یاد گرفتم! بعدی
            </a>
        <?php endif; ?> <!--[if ENDBLOCK]><![endif]-->
    </div>
</div>
<?php /**PATH D:\00programming\projects\EnLangSentences\resources\views/livewire/answer-input.blade.php ENDPATH**/ ?>