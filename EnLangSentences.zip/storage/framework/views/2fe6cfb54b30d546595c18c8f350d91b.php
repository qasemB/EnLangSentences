<nav class="navbar bg_blue">
    
    <div class="container-fluid">
        <a class="navbar-brand" href="/">
            <img src="/images/logo.png" alt="Bootstrap" width="30" height="24"
                style="filter: drop-shadow(0 0 2px blue)">
        </a>
        <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('offline-status', []);

$__html = app('livewire')->mount($__name, $__params, 'CW6P9gw', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
        <?php if(Auth::check()): ?>
            <?php
                $c = new Carbon\Carbon(Auth::user()->last_practice_at)
            ?>
            <?php if(Carbon\Carbon::now()->format("Y-m-d") != $c->format("Y-m-d")): ?>
                <small class="text-white" title="Last practice at:">LP : <?php echo e($c->shortRelativeDiffForHumans()); ?></small>
            <?php endif; ?>
        <?php endif; ?>


        <div class="rounded-circle border d-flex p-0 justify-content-center align-items-center navbar-toggler pointer"
            style="width:35px;height:35px" alt="Avatar" data-bs-toggle="offcanvas" data-bs-target="#offcanvasNavbar"
            aria-controls="offcanvasNavbar">
            <?php if(Auth::check()): ?>
                <?php if(Auth::user()->avatar): ?>
                    <img src="<?php echo e(Auth::user()->avatar); ?>" class="w-100">
                <?php else: ?>
                    <i class="fa-solid fa-user text-white"></i>
                <?php endif; ?>
            <?php else: ?>
                <i class="fa-solid fa-bars text-white"></i>
            <?php endif; ?>
        </div>
        
        
        
        <div class="min_w_100 offcanvas offcanvas-end" tabindex="-1" id="offcanvasNavbar"
            aria-labelledby="offcanvasNavbarLabel">
            <div class="offcanvas-header ">
                <?php if(Auth::check()): ?>
                    <div class="rounded-circle border d-flex p-0 justify-content-center align-items-center"
                        style="width:55px;height:55px" alt="Avatar">
                        <img src="/images/avatar.png" class="w-100">
                    </div>
                <?php endif; ?>
                <button type="button" class="btn-close" data-bs-dismiss="offcanvas" aria-label="Close"></button>
            </div>
            <div class="offcanvas-body" id="main_menu">
                <ul class="navbar-nav justify-content-end flex-grow-1 mt-4 pe-3">
                    <li class="nav-item">
                        <a class="nav-link text-center <?php echo e(request()->route()->uri() == '/'? 'active': ''); ?>"
                            aria-current="page" href="/">Home</a>
                    </li>
                    <?php if(Auth::check()): ?>
                        <li class="nav-item">
                            <a class="nav-link text-center <?php echo e(request()->route()->uri() == 'settings'? 'active': ''); ?>"
                                href="#">Settings</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link text-center <?php echo e(request()->route()->uri() == 'progress'? 'active': ''); ?>"
                                href="#">Progress</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link text-center" href="/logout">Logout</a>
                        </li>
                    <?php else: ?>
                        <li class="nav-item">
                            <a class="nav-link text-center <?php echo e(request()->route()->uri() == 'login'? 'active': ''); ?>"
                                href="/login">Login</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link text-center <?php echo e(request()->route()->uri() == 'register'? 'active': ''); ?>"
                                href="/register">Register</a>
                        </li>
                    <?php endif; ?>

                    <hr class="border">

                    <?php if(Auth::check()): ?>
                        <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('menu-scores', []);

$__html = app('livewire')->mount($__name, $__params, 'KYFufvy', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
                    <?php endif; ?>

                </ul>
                
                
                
                
            </div>
        </div>
    </div>
</nav>
<?php /**PATH D:\00programming\projects\EnLangSentences\resources\views/partials/mainNavbar.blade.php ENDPATH**/ ?>