<?php if(session('successLogin')): ?>
    <script>
        handleToastify("You have successfully logged in", "success")
    </script>
    
<?php endif; ?>
<?php /**PATH D:\00programming\projects\EnLangSentences\resources\views/partials/alerts.blade.php ENDPATH**/ ?>