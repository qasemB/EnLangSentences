<div wire:loading id="loading_box" class="text-center pt-5">
    <div class="spinner-border text_blue" style="width: 5rem; height: 5rem;" role="status">
        <span class="visually-hidden">Loading...</span>
    </div>
</div>
<?php /**PATH D:\00programming\projects\EnLangSentences\resources\views/livewire/loading.blade.php ENDPATH**/ ?>