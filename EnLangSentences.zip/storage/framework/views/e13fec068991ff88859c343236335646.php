<?php $__env->startSection('content'); ?>
    
    <h3 class="text-center mt-4">
        کلمات انگلیسی رو
        <span class="text_pink">
            به خاطر بسپار
        </span>
    </h3>
    <h3 class="text-center mt-3">
        با
        <span class="text_pink">جملات</span>
        خودت
    </h3>

    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('typing-sentence-box', []);

$__html = app('livewire')->mount($__name, $__params, 'uAJEwBm', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>

    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('answer-input', []);

$__html = app('livewire')->mount($__name, $__params, '0bjak73', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>

    

    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('add-sentence', []);

$__html = app('livewire')->mount($__name, $__params, 'M1ujubY', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('pageJS'); ?>
    <script src="/<?php echo e(env("ASSETS_FOLDER")); ?>/js/index.js"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts._main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\00programming\projects\EnLangSentences\resources\views/index.blade.php ENDPATH**/ ?>